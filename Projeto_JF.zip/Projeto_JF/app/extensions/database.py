from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

def init_app(app):
    
    app.config["SQLALCHEMY_DATABASE_URI"] = "mysql+pymysql://root:150188@localhost/jf_barbearia"

    db.init_app(app)

# """Criando Tabelas do Banco de Dados"""
class users(db.Model):
    id = db.Column("id", db.Integer, primary_key=True, autoincrement=True)
    nome =  db.Column(db.String(100))
    senha = db.Column(db.String(100))
    email = db.Column(db.String(100))
    telefone = db.Column(db.String(20))
    adm = db.Column(db.Boolean, default=False, nullable=False)

    def __init__(self, nome, senha, email, telefone):
        self.nome = nome
        self.senha = senha
        self.email = email
        self.telefone = telefone

class Products(db.Model):
    id = db.Column("Cod.P",db.Integer, primary_key=True,autoincrement=True)
    name =  db.Column(db.String(100))
    price = db.Column(db.String(100))
    quantity = db.Column(db.String(100))

    def __init__(self, name, price, quantity):
        self.name = name
        self.price = price
        self.quantity = quantity

class agendamento(db.Model):
    id = db.Column("id", db.Integer, primary_key=True, autoincrement=True)
    nome =  db.Column(db.String(100))
    email = db.Column(db.String(100))
    horarios = db.Column(db.String(100))

    def __init__(self, nome,email, horarios):
        self.nome = nome
        self.email = email
        self.horarios = horarios
