from flask import render_template, request, url_for, redirect

from hashlib import sha256

from app.extensions.database import users, db, Products, agendamento

def init_app(app):

    @app.route("/dashboard")
    def pag_adm():
        return render_template('/Adm/dashboard.html')

    @app.route('/registrados', methods=["GET"])
    def registrados():
        clientes = users.query.all()
        return render_template('/Adm/cadastrados.html', clientes=clientes)

    @app.route('/produtos_registrados', methods=["GET"])
    def prod_cadastrados():
        produtos = Products.query.all()
        return render_template('/Adm/produtos_cadastrados.html', produtos=produtos)

        # """Página de Clientes"""
    @app.route('/cadastrar', methods=["GET","POST"])
    def adicionar_clientes():
        if request.method == "POST":
            passw = request.form['senha']
            clientes = users(request.form['nome'], sha256(passw.encode()).hexdigest(), request.form['email'], request.form['telefone'])
            db.session.add(clientes)
            db.session.commit()
            return redirect(url_for('index'))
        return render_template('/Adm/cadastrar.html')

    @app.route('/deletarClientes/<int:id>')
    def deletar_clientes(id):
        clientes = users.query.get(id)
        db.session.delete(clientes)
        db.session.commit()
        return redirect(url_for("pag_adm"))

    @app.route('/editarClientes/<int:id>', methods=["GET","POST"])
    def editar_clientes(id):
        clientes =  users.query.get(id)
        if request.method == "POST":
            passw = request.form['senha']
            clientes.nome = request.form['nome']
            clientes.senha = sha256(passw.encode()).hexdigest()
            clientes.email = request.form['email']
            clientes.telefone = request.form['telefone']
            db.session.commit()
            return redirect(url_for('pag_adm'))
        return render_template('/Adm/editar_cadastro.html', clientes=clientes)

    # Cadastramento e edição de horarios
    @app.route('/agendarhorario', methods=["GET","POST"])
    def cadastrahorarios():
        if request.method == "POST":
            agenda = agendamento(request.form['nome'], request.form['email'], request.form['horarios'])
            db.session.add(agenda)
            db.session.commit()
            return redirect(url_for("index"))
        return render_template('/Adm/horarios.html')

    @app.route('/horarios', methods=["GET"])
    def horarios():
        agenda = agendamento.query.all()
        return render_template("/Adm/horarioscadastrados.html", agenda=agenda)

    @app.route('/editarhorarios/<int:id>', methods=["GET","POST"])
    def editar_horarios(id):
        agenda =  agendamento.query.get(id)
        if request.method == "POST":
            agenda.nome = request.form['nome']
            agenda.email = request.form['email']
            agenda.horarios = request.form['horarios']
            db.session.commit()
            return redirect(url_for('pag_adm'))
        return render_template('/Adm/editarhorarios.html', agenda=agenda)

    @app.route('/deletarhorarios/<int:id>')
    def deleta_horarios(id):
        deletar = agendamento.query.get(id)
        db.session.delete(deletar)
        db.session.commit()
        return redirect(url_for('pag_adm'))

        # """Página de Produtos"""
    @app.route('/cadastrar_produtos', methods=["GET","POST"])
    def cadastrar_produtos():
        if request.method == "POST":
            produtos = Products(request.form['name'], request.form['price'], request.form['quantity'])
            db.session.add(produtos)
            db.session.commit()
            return redirect(url_for('pag_adm'))
        return render_template('/Adm/cadastrar_produtos.html')

    @app.route('/editarProdutos/<int:id>', methods=["GET","POST"])
    def editar_produtos(id):
        produtos = Products.query.get(id)
        if request.method == "POST":
            produtos.name = request.form['price']
            return redirect(url_for('prod_cadastrados'))
        return render_template('/Adm/editar_produtos.html', produtos=produtos)

    @app.route('/deletarProdutos/<int:id>')
    def deletar_produtos(id):
        produtos = Products.query.get(id)
        db.session.delete(produtos)
        db.session.commit()
        return redirect(url_for("pag_adm"))
