from flask import render_template, redirect, url_for, request

from sqlalchemy import create_engine
from sqlalchemy.sql import text


from hashlib import sha256

from app.extensions.database import users, Products

def init_app(app):

    engine = create_engine(app.config["SQLALCHEMY_DATABASE_URI"])

    @app.route("/clientesindex", methods=["GET"])
    def pag_clientes():
        return render_template("/Users/pag_clientes.html")

    @app.route("/historia", methods=["GET"])
    def historia():
        return render_template("/Users/historia.html")

    @app.route("/servicos", methods=["GET"])
    def servicos():
        return render_template("/Users/serviços.html")

    @app.route("/faleconosco",methods=["GET","POST"])
    def fale_conosco():
        return render_template("/Users/fale_Conosco.html")

    # """Login and auth"""
    @app.route('/login', methods=["GET","POST"])
    def login():
        return render_template('/Users/login.html')

    @app.route("/auth", methods=["POST"])
    def auth():
        statement = text("SELECT * FROM users WHERE email = :email AND senha = :senha")
        email = request.form['email']
        senha = request.form['senha']
        senhahash = sha256(senha.encode()).hexdigest()
        result = engine.connect().execute(statement, email=email, senha=senhahash).fetchone()
        if result:
            if result[-1]:
                return redirect(url_for("pag_adm"))
            else:
                return redirect(url_for('pag_clientes'))
        else:
            return redirect(url_for('adicionar_clientes'))